﻿CREATE FUNCTION [aud].[fn_AuditFileGet]
(@filename NVARCHAR (512), @fileoffset BIGINT)
RETURNS TABLE 
AS
RETURN 
    (
    with log_file_cte as (
		select event_time							= aud.event_time
				, sequence_number					= aud.sequence_number
				, succeeded							= aud.succeeded
				, permission_bitmask				= aud.permission_bitmask
				, is_column_permission				= aud.is_column_permission
				, session_id						= aud.session_id
				, statement							= REPLACE(REPLACE(cast(aud.statement as nvarchar(4000)),CHAR(10), ' '), CHAR(13), ' ') 
				, additional_information			= cast(aud.additional_information as nvarchar(4000))
				, file_name							= aud.file_name
				, audit_file_offset					= aud.audit_file_offset
				, action_id							= upper(aud.action_id)
				, class_type						= upper(aud.class_type)
				, session_server_principal_name		= upper(aud.session_server_principal_name)
				, server_principal_name				= upper(aud.server_principal_name)
				, target_server_principal_name		= upper(aud.target_server_principal_name)
				, database_principal_name			= upper(aud.database_principal_name)
				, target_database_principal_name	= upper(aud.target_database_principal_name)
				, server_instance_name				= upper(left(aud.server_instance_name, 110))
				, database_name						= upper(left(aud.database_name, 110))
				, schema_name						= upper(left(aud.schema_name, 110))
				, object_name						= upper(left(aud.object_name, 110))

				, pooled_connection					= CASE WHEN action_id IN ('LGIF', 'LGIS')
														THEN CAST(additional_information as xml).value(N'declare namespace sqlaudit="http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data";(/sqlaudit:action_info/sqlaudit:pooled_connection[1]/text())[1]', 'bit')
														ELSE NULL
													  END
				, packet_data_size					= CASE WHEN action_id IN ('LGIF', 'LGIS')
														THEN CAST(additional_information as xml).value(N'declare namespace sqlaudit="http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data";(/sqlaudit:action_info/sqlaudit:packet_data_size[1]/text())[1]', 'int')
														ELSE NULL
													  END
				, address							= ISNULL(CASE WHEN action_id IN ('LGIF', 'LGIS')
														THEN CAST(additional_information as xml).value(N'declare namespace sqlaudit="http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data";(/sqlaudit:action_info/sqlaudit:address[1]/text())[1]', 'nvarchar(50)')
														ELSE NULL
													  END, '')
				, is_dac							= CASE WHEN action_id IN ('LGIF', 'LGIS')
														THEN CAST(additional_information as xml).value(N'declare namespace sqlaudit="http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data";(/sqlaudit:action_info/sqlaudit:is_dac[1]/text())[1]', 'bit')
														ELSE NULL
													  END

				, total_cpu							= CASE WHEN action_id IN ('LGO')
														THEN CAST(additional_information as xml).value(N'declare namespace sqlaudit="http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data";(/sqlaudit:action_info/sqlaudit:total_cpu[1]/text())[1]', 'int')
														ELSE NULL
													  END
				, reads								= CASE WHEN action_id IN ('LGO')
														THEN CAST(additional_information as xml).value(N'declare namespace sqlaudit="http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data";(/sqlaudit:action_info/sqlaudit:reads[1]/text())[1]', 'int')
														ELSE NULL
													  END
				, writes							= CASE WHEN action_id IN ('LGO')
														THEN CAST(additional_information as xml).value(N'declare namespace sqlaudit="http://schemas.microsoft.com/sqlserver/2008/sqlaudit_data";(/sqlaudit:action_info/sqlaudit:writes[1]/text())[1]', 'int')
														ELSE NULL
													  END
		  from sys.fn_get_audit_file(@filename, @filename, @fileoffset) aud
		  )
		select event_time							
				, sequence_number					
				, succeeded							
				, permission_bitmask				
				, is_column_permission				
				, session_id						
				, [log_file_cte].[statement]
				,HASHBYTES('SHA2_512',log_file_cte.statement) AS statement_hash
				,SUBSTRING(statement, IIF(LEN(statement) - 400 >= 0, LEN(statement) - 400, 0), IIF(LEN(statement) < 400, LEN(statement),400)) AS statement_tail
				, additional_information			
				, file_name							
				, audit_file_offset					
				, action_id							
				, class_type						
				, session_server_principal_name		
				, server_principal_name				
				, target_server_principal_name		
				, database_principal_name			
				, target_database_principal_name	
				, server_instance_name				
				, database_name						
				, schema_name						
				, object_name						
				, pooled_connection					
				, packet_data_size					
				, address							
				, is_dac							
				, total_cpu							
				, reads								
				, writes							
				, event_count = count(*) 
		  from log_file_cte
		 group by event_time							
				, sequence_number					
				, succeeded							
				, permission_bitmask				
				, is_column_permission				
				, session_id						
				, statement	
				,HASHBYTES('SHA2_512',log_file_cte.statement)
				, additional_information			
				, file_name							
				, audit_file_offset					
				, action_id							
				, class_type						
				, session_server_principal_name		
				, server_principal_name				
				, target_server_principal_name		
				, database_principal_name			
				, target_database_principal_name	
				, server_instance_name				
				, database_name						
				, schema_name						
				, object_name						
				, pooled_connection					
				, packet_data_size					
				, address							
				, is_dac							
				, total_cpu							
				, reads								
				, writes							


	)
