﻿CREATE function [aud].[fn_GetServerInstanceName] (
	@Audit_File_Name nvarchar(128)
) returns nvarchar(128)
as
begin
	declare @i int, @j int, @InstanceName nvarchar(128)
	set @i = CHARINDEX('SQLAudit$', @Audit_File_Name)
	set @InstanceName = SUBSTRING(@Audit_File_Name, @i + 9, 128)
	set @j = CHARINDEX('_', @InstanceName)
	set @InstanceName = replace(SUBSTRING(@InstanceName, 1, @j - 1), '$', '\')
	return (@InstanceName)


end
