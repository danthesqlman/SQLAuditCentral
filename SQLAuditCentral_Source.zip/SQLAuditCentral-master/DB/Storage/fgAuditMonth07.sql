﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILEGROUP [fgAuditMonth07];

