﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILEGROUP [fgAuditMonth02];

