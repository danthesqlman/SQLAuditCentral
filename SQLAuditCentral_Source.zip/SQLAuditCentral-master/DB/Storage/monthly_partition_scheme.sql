﻿CREATE PARTITION SCHEME [monthly_partition_scheme]
    AS PARTITION [monthly_partition_function]
    TO ([fgAuditMonth10], [fgAuditMonth11], [fgAuditMonth12], [fgAuditMonth01], [fgAuditMonth02], [fgAuditMonth03], [fgAuditMonth04], [fgAuditMonth05], [fgAuditMonth06], [fgAuditMonth07], [fgAuditMonth08], [fgAuditMonth09], [PRIMARY]);

