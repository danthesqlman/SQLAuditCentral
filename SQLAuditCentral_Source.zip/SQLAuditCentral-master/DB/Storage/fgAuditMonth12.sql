﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILEGROUP [fgAuditMonth12];

