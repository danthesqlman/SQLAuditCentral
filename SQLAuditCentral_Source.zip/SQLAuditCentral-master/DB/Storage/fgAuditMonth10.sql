﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILEGROUP [fgAuditMonth10];

