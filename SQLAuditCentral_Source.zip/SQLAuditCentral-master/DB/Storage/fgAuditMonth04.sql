﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILEGROUP [fgAuditMonth04];

