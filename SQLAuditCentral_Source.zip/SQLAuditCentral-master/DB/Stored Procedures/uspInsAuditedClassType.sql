﻿CREATE PROCEDURE [aud].[uspInsAuditedClassType]
@class_type VARCHAR (2)
AS
SET NOCOUNT ON;

WITH classcte AS (
	SELECT class_type
			, class_type_desc 
			, securable_class_desc
	  FROM sys.dm_audit_class_type_map 
	 WHERE class_type = RTRIM(LTRIM(IsNull(@class_type, 'ZZ')))
	)
MERGE aud.AuditedClassType AS target
USING classcte AS source 
   ON (target.class_type = source.class_type)
 WHEN NOT MATCHED THEN 
	INSERT (class_type, class_type_desc, securable_class_desc)
	VALUES (source.class_type, source.class_type_desc, source.securable_class_desc)
	;

SELECT *
  FROM aud.AuditedClassType 
 WHERE class_type = IsNull(@class_type, 'ZZ')
