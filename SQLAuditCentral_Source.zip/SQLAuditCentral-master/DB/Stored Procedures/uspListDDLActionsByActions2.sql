﻿Create Procedure [aud].[uspListDDLActionsByActions2]
     @Instance_name nvarchar(128), @DB_Name nvarchar(128) = NULL, @EventDate smalldatetime,
     @Action_name nvarchar(128) = NULL, @Class_type nvarchar(128)= NULL
AS

/*

List DDL Actions by Instance by Action Name

*/
     
Declare @TimeDiff int

Select @TimeDiff = DATEDIFF(hh,GETUTCDATE(),GETDATE())


IF @Class_type IS NULL AND @Action_name is NULL AND @DB_Name IS NULL
Begin
	SELECT D1.event_time AS UTC_Time, DATEADD(hh,@TimeDiff,D1.event_time) AS event_time, A.action_name, C1.class_type_desc, O.object_name, 
	O.schema_name, C2.client_address, D2.database_principal_name, 
	S2.server_principal_name, S1.statement, D1.event_count
	FROM aud.AuditLog_DDLActions D1 
	join aud.auditedAction A on D1.audited_action_id = A.audited_action_id
	join aud.AuditedClassType C1 on D1.audited_class_type_id = C1.audited_class_type_id
	join aud.AuditedObject O on D1.audited_object_id = O.audited_object_id
	join aud.ClientAddress C2 on D1.client_address_id = C2.client_address_id
	join aud.DatabasePrincipalName D2 on D1.database_principal_name_id = D2.database_principal_name_id
	join aud.ServerPrincipalName S2 on D1.server_principal_name_id = S2.server_principal_name_id
	join aud.Statement S1 on D1.statement_id = S1.statement_id
	Where O.server_instance_name = @Instance_name
		AND Cast(DATEADD(hh,@TimeDiff,D1.event_time) AS DATE) = @EventDate

	Order by D1.event_time
End


IF @Class_type IS NOT NULL AND @Action_name is NULL AND @DB_Name IS NULL
Begin
	SELECT D1.event_time AS UTC_Time, DATEADD(hh,@TimeDiff,D1.event_time) AS event_time, A.action_name, C1.class_type_desc, O.object_name, 
	O.schema_name, C2.client_address, D2.database_principal_name, 
	S2.server_principal_name, S1.statement, D1.event_count
	FROM aud.AuditLog_DDLActions D1 
	join aud.auditedAction A on D1.audited_action_id = A.audited_action_id
	join aud.AuditedClassType C1 on D1.audited_class_type_id = C1.audited_class_type_id
	join aud.AuditedObject O on D1.audited_object_id = O.audited_object_id
	join aud.ClientAddress C2 on D1.client_address_id = C2.client_address_id
	join aud.DatabasePrincipalName D2 on D1.database_principal_name_id = D2.database_principal_name_id
	join aud.ServerPrincipalName S2 on D1.server_principal_name_id = S2.server_principal_name_id
	join aud.Statement S1 on D1.statement_id = S1.statement_id
	Where O.server_instance_name = @Instance_name 
		AND Cast(DATEADD(hh,@TimeDiff,D1.event_time) AS DATE) = @EventDate
		AND C1.class_type_desc = @Class_type
	Order by D1.event_time
End


IF @Class_type IS NOT NULL AND @Action_name is NOT NULL AND @DB_Name IS NULL
Begin
	SELECT D1.event_time AS UTC_Time, DATEADD(hh,@TimeDiff,D1.event_time) AS event_time, A.action_name, C1.class_type_desc, O.object_name, 
	O.schema_name, C2.client_address, D2.database_principal_name, 
	S2.server_principal_name, S1.statement, D1.event_count
	FROM aud.AuditLog_DDLActions D1 
	join aud.auditedAction A on D1.audited_action_id = A.audited_action_id
	join aud.AuditedClassType C1 on D1.audited_class_type_id = C1.audited_class_type_id
	join aud.AuditedObject O on D1.audited_object_id = O.audited_object_id
	join aud.ClientAddress C2 on D1.client_address_id = C2.client_address_id
	join aud.DatabasePrincipalName D2 on D1.database_principal_name_id = D2.database_principal_name_id
	join aud.ServerPrincipalName S2 on D1.server_principal_name_id = S2.server_principal_name_id
	join aud.Statement S1 on D1.statement_id = S1.statement_id
	Where O.server_instance_name = @Instance_name
		AND Cast(DATEADD(hh,@TimeDiff,D1.event_time) AS DATE) = @EventDate
		AND A.action_name = @Action_name AND C1.class_type_desc = @Class_type
	Order by D1.event_time
End


IF @Class_type IS NOT NULL AND @Action_name is NOT NULL AND @DB_Name IS NOT NULL
Begin
	SELECT D1.event_time AS UTC_Time, DATEADD(hh,@TimeDiff,D1.event_time) AS event_time, A.action_name, C1.class_type_desc, O.object_name, 
	O.schema_name, C2.client_address, D2.database_principal_name, 
	S2.server_principal_name, S1.statement, D1.event_count
	FROM aud.AuditLog_DDLActions D1 
	join aud.auditedAction A on D1.audited_action_id = A.audited_action_id
	join aud.AuditedClassType C1 on D1.audited_class_type_id = C1.audited_class_type_id
	join aud.AuditedObject O on D1.audited_object_id = O.audited_object_id
	join aud.ClientAddress C2 on D1.client_address_id = C2.client_address_id
	join aud.DatabasePrincipalName D2 on D1.database_principal_name_id = D2.database_principal_name_id
	join aud.ServerPrincipalName S2 on D1.server_principal_name_id = S2.server_principal_name_id
	join aud.Statement S1 on D1.statement_id = S1.statement_id
	Where O.server_instance_name = @Instance_name 
		AND Cast(DATEADD(hh,@TimeDiff,D1.event_time) AS DATE) = @EventDate
		AND A.action_name = @Action_name AND C1.class_type_desc = @Class_type AND O.database_name = @DB_Name
	Order by D1.event_time
End
