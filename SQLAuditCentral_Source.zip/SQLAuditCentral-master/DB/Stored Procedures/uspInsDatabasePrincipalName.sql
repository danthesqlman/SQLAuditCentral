﻿CREATE PROCEDURE [aud].[uspInsDatabasePrincipalName]
@database_principal_name NVARCHAR (128)
AS
SET NOCOUNT ON ;
WITH namecte AS (
	SELECT database_principal_name = RTRIM(LTRIM(@database_principal_name))
	)
MERGE aud.DatabasePrincipalName AS target
USING namecte AS source 
   ON (target.database_principal_name = source.database_principal_name)
 WHEN NOT MATCHED THEN 
	INSERT (database_principal_name)
	VALUES (database_principal_name)
	;

SELECT * 
  FROM aud.DatabasePrincipalName 
   WHERE database_principal_name = RTRIM(LTRIM(@database_principal_name))
