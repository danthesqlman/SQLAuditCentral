﻿CREATE PROCEDURE [aud].[uspInsClientAddress]
@client_address NVARCHAR (50)
AS
SET NOCOUNT ON 

if @client_address is null
begin
	select @client_address = ''
end

;
WITH addresscte AS (
	SELECT client_address = RTRIM(LTRIM(@client_address))
	)
MERGE aud.ClientAddress AS target
USING addresscte AS source 
   ON (target.client_address = source.client_address)
 WHEN NOT MATCHED THEN 
	INSERT (client_address)
	VALUES (client_address)
	;

SELECT * 
  FROM aud.ClientAddress 
   WHERE client_address = RTRIM(LTRIM(@client_address))
