﻿CREATE PROCEDURE [aud].[uspImportedFileGetLastImportedOffset]
@import_id INT, @file_name NVARCHAR (260), @file_offset BIGINT OUTPUT
AS
SELECT @file_name = RTRIM(LTRIM(@file_name));

DECLARE @audit_guid AS UNIQUEIDENTIFIER, @audit_file_timestamp AS BIGINT, @audit_file_name_trimmed AS NVARCHAR (260);
SELECT @audit_guid = audit_guid,
       @audit_file_timestamp = audit_file_timestamp,
       @audit_file_name_trimmed = audit_file_name_trimmed
FROM   aud.fn_GetAuditFileInfo(@file_name);
IF EXISTS (SELECT TOP 1 1
           FROM   aud.AuditFile
           WHERE  audit_guid = @audit_guid
                  AND audit_file_timestamp >= @audit_file_timestamp)
   AND EXISTS (SELECT TOP 1 1
               FROM   aud.AuditFile
               WHERE  audit_file_name_trimmed = @audit_file_name_trimmed)
    BEGIN
        SELECT @file_offset = -1;
    END
ELSE
    BEGIN
        SELECT @file_offset = ISNULL(MAX(audit_file_offset_max), 0)
        FROM   aud.ImportedFile
        WHERE  file_name = @file_name;
    END
IF @file_offset = 0
    SELECT @file_offset = MIN(audit_file_offset)
    FROM   sys.fn_get_audit_file(@file_name, NULL, NULL);

INSERT aud.ImportFileLog(import_id, file_name, last_imported_offset)
VALUES (@import_id, @file_name, @file_offset)  
