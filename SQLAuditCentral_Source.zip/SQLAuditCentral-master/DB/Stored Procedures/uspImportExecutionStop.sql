﻿CREATE PROCEDURE [aud].[uspImportExecutionStop]
@import_id INT
AS
UPDATE aud.ImportExecution
   SET stopped_time = getdate()
 WHERE import_id = @import_id
