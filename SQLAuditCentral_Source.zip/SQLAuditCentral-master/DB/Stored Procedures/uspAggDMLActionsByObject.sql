﻿create procedure [aud].[uspAggDMLActionsByObject] (
	@StartTime smalldatetime, 
	@EndTime smalldatetime,
	@Instance_name nvarchar(128) = null, 
	@DB_Name nvarchar(128) = null, 
	@Schema_Name nvarchar(128) = null,
	@Object_Name nvarchar(128) = null	
)
as
begin
	-- query optimization
	set nocount on

	-- Query
	select 
		EventDate, 
		server_instance_name, 
		database_principal_name, 
		database_name, 
		[schema_name], 
		[object_name], 
		DMLActionCount
	from aud.rptAggDMLActionsByObject (NoLock)
	where
		EventDate >= @StartTime and EventDate <= @EndTime	-- time
		and (server_instance_name = @Instance_name or @Instance_name is null)
		and (database_name = @DB_Name or @DB_Name is null)
		and ([schema_name] = @Schema_Name or @Schema_Name is null)
		and ([object_name] = @Object_Name or @Object_Name is null)
		
end
