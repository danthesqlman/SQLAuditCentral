﻿CREATE PROCEDURE [aud].[uspInsServerPrincipalName]
@server_principal_name NVARCHAR (128)
AS
SET NOCOUNT ON;

WITH namecte AS (
	SELECT server_principal_name = RTRIM(LTRIM(@server_principal_name))
	)
MERGE aud.ServerPrincipalName AS target
USING namecte AS source 
   ON (target.server_principal_name = source.server_principal_name)
 WHEN NOT MATCHED THEN 
	INSERT (server_principal_name)
	VALUES (server_principal_name)
	;
 
SELECT * 
  FROM aud.ServerPrincipalName 
 WHERE server_principal_name = RTRIM(LTRIM(@server_principal_name))
