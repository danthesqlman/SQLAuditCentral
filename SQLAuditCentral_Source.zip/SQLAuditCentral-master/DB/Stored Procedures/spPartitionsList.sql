﻿CREATE proc [dbo].[spPartitionsList]
AS
With R (boundary_id, value) AS
(select boundary_id, value from sys.partition_range_values
 where function_id in (select function_id 
      from sys.partition_functions
       where name in ('monthly_partition_function'))
)

--View the distribution of data in the partitions
SELECT R.value, ps.partition_number ,ps.row_count , ps.used_page_count
      
FROM sys.dm_db_partition_stats ps
INNER JOIN sys.partitions p
ON ps.partition_id = p.partition_id
AND p.[object_id] = OBJECT_ID('aud.AuditLog_ServerActions')
INNER JOIN R on ps.partition_number = R.boundary_id+1

Where p.index_id = 1
Order by R.value
