﻿CREATE PROCEDURE [aud].[uspInsAuditFile]
@audit_file_name NVARCHAR (512)
AS
SET NOCOUNT ON ;

select @audit_file_name = RTRIM(ltrim(@audit_file_name))

declare @audit_file_info table (
			audit_name nvarchar(128)
			, audit_guid nvarchar(50)
			, audit_file_partition nvarchar(10)
			, audit_file_timestamp nvarchar(50)
			, audit_file_name nvarchar(260)
			, audit_file_name_trimmed nvarchar(260)
			, audit_file_path nvarchar(260)
			, audit_file_extension nvarchar(260)
			);
insert into @audit_file_info (
	audit_name 
	, audit_guid 
	, audit_file_partition 
	, audit_file_timestamp 
	, audit_file_name
	, audit_file_name_trimmed 
	, audit_file_path 
	, audit_file_extension 
	)
	select audit_name 
			, audit_guid 
			, audit_file_partition 
			, audit_file_timestamp 
			, audit_file_name
			, audit_file_name_trimmed
			, audit_file_path
			, audit_file_extension
	  from aud.fn_GetAuditFileInfo(@audit_file_name)

declare @server_instance_name nvarchar(110)

if exists(
		select top 1 1 
		  from aud.AuditFile f
		  join @audit_file_info i
		    on f.audit_guid = i.audit_guid
		    )
begin
	select top 1 @server_instance_name = f.audit_file_source_server
	  from aud.AuditFile f
	  cross join @audit_file_info i
	 where f.audit_guid = i.audit_guid
end
else
begin

	begin try
		declare @audit_file_namepat nvarchar(260)
		select @audit_file_namepat = i.audit_file_path + '\' + i.audit_name + '_' + i.audit_guid + '*.' + i.audit_file_extension
		  from @audit_file_info i
		
		select top 1 @server_instance_name = server_instance_name
		  from fn_get_audit_file(@audit_file_namepat, default, default)
		 where  action_id = 'AUSC'
	 end try
	 begin catch
		select top 1 @server_instance_name = ''
	 end catch
	 
	 /* Additional Logic for the server_instance_name */
	 if ISNULL(@server_instance_name, '') = '' set @server_instance_name = [aud].[fn_GetServerInstanceName](@audit_file_namepat);
end;
WITH filecte AS (
	SELECT *
	  from @audit_file_info	
	)
MERGE aud.AuditFile AS target
USING filecte AS source 
   ON (target.audit_file_name = source.audit_file_name)
 WHEN NOT MATCHED THEN 
insert (
	audit_name 
	, audit_guid 
	, audit_file_partition 
	, audit_file_timestamp 
	, audit_file_name
	, audit_file_name_trimmed 
	, audit_file_path 
	, audit_file_extension 
	, audit_file_source_server
	)
	values (
	audit_name 
	, audit_guid 
	, audit_file_partition 
	, audit_file_timestamp 
	, audit_file_name
	, audit_file_name_trimmed 
	, audit_file_path 
	, audit_file_extension 
	, @server_instance_name
	)
	;

SELECT * 
  FROM aud.AuditFile 
 WHERE audit_file_name = RTRIM(LTRIM(@audit_file_name))


PRINT N'Creating uspInsAuditedObject';
