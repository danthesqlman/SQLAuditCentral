﻿create procedure [aud].[uspAggDDLActionsByClass] (
	@StartTime smalldatetime, 
	@EndTime smalldatetime,
	@Instance_name nvarchar(128) = null, 
	@DB_Name nvarchar(128) = null, 
	@Class_Type nvarchar(128) = null,
	@Action_Name nvarchar(128) = null
)
as
begin
	-- query optimization
	set nocount on

	-- Query
	select 
		EventDate, 
		server_instance_name, 
		database_principal_name, 
		database_name, 
		action_name, 
		class_type_desc, 
		securable_class_desc,  
		DDLActionCount
	from aud.rptAggDDLActionsByClass (NoLock)
	where
		EventDate >= @StartTime and EventDate <= @EndTime	-- time
		and (server_instance_name = @Instance_name or @Instance_name is null)
		and (database_name = @DB_Name or @DB_Name is null)
		and (class_type_desc = @Class_Type or @Class_Type is null)
		and (action_name = @Action_Name or @Action_Name is null)
end
