﻿Create Proc [aud].[uspDataGromming]
AS
Declare @chunkDeleted  int
Declare @TotalDeleted int
Declare @ROWCNT int


SET ROWCOUNT 100000

SET @chunkDeleted = 1
SET @TotalDeleted = 0

WHILE ( @chunkDeleted > 0 )
Begin
	Delete From aud.AuditLog_ServerActions  where audited_action_id = 3
    SET @RowCNT = @@ROWCOUNT
	SET @chunkDeleted = @ROWCNT
	SET @TotalDeleted = @RowCNT + @TotalDeleted
	Select @TotalDeleted
End

Print '** Delete from Audit Server Actions completed **'
