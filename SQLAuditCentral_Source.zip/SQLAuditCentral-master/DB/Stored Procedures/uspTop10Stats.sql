﻿create proc [aud].[uspTop10Stats]
AS
Select Server_instance_name AS InstanceName, SUM(ActionCount) AS ActionCount, MIN(eventdate) AS StartDate, MAX(eventdate) AS EndDate
from aud.vAggALLActionsByClass
Where EVENTDATE > GETDATE()-8 AND server_instance_name <> ''
Group by server_instance_name
Order by ActionCount desc


Select Top 10 Database_name AS DBName, SUM(ActionCount) AS ActionCount, MIN(eventdate) AS StartDate, MAX(eventdate) AS EndDate 
from aud.vAggALLActionsByClass
Where EVENTDATE > GETDATE()-8 AND database_name <> ''
Group by database_name
Order by ActionCount desc


Select Top 10 Action_name AS ActionName, SUM(ActionCount) AS ActionCount, MIN(eventdate) AS StartDate, MAX(eventdate) AS EndDate 
from aud.vAggALLActionsByClass
Where EVENTDATE > GETDATE()-8 AND Action_Name <> ''
Group by Action_name
Order by ActionCount desc

Select Top 10 database_principal_name AS UserName, SUM(ActionCount) AS ActionCount, MIN(eventdate) AS StartDate, MAX(eventdate) AS EndDate
from aud.vAggALLActionsByClass
Where EVENTDATE > GETDATE()-8 AND database_principal_name <> ''
Group by database_principal_name
Order by ActionCount desc


Select Top 10 class_type_desc AS ActionClass, SUM(ActionCount) AS ActionCount, MIN(eventdate) AS StartDate, MAX(eventdate) AS EndDate
from aud.vAggALLActionsByClass
Where EVENTDATE > GETDATE()-8 AND class_type_desc <> ''
Group by class_type_desc
Order by ActionCount desc
