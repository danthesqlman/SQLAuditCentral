﻿CREATE PROCEDURE [aud].[uspInsAuditedObject]
@server_instance_name NVARCHAR (110), @database_name NVARCHAR (110), @schema_name NVARCHAR (110), @object_name NVARCHAR (110)
AS
SET NOCOUNT ON;
WITH objectcte AS (
	SELECT server_instance_name = RTRIM(LTRIM(@server_instance_name))
	, database_name = RTRIM(LTRIM(@database_name))
	, schema_name = RTRIM(LTRIM(@schema_name))
	, object_name = RTRIM(LTRIM(@object_name))
	)
MERGE aud.AuditedObject AS target
USING objectcte AS source 
   ON (
		    target.server_instance_name = source.server_instance_name
		AND target.database_name = source.database_name
		AND target.schema_name = source.schema_name
		AND target.object_name = source.object_name
	)
 WHEN NOT MATCHED THEN 
	INSERT (server_instance_name, database_name, schema_name, object_name)
	VALUES (server_instance_name, database_name, schema_name, object_name)
;

SELECT *
  FROM aud.AuditedObject
 WHERE server_instance_name = RTRIM(LTRIM(@server_instance_name))
   AND database_name = RTRIM(LTRIM(@database_name))
   AND schema_name = RTRIM(LTRIM(@schema_name))
   AND object_name = RTRIM(LTRIM(@object_name))
