﻿CREATE TABLE [aud].[rptAggDDLActionsByClass] (
    [EventDate]               SMALLDATETIME  NOT NULL,
    [server_instance_name]    NVARCHAR (128) NULL,
    [database_principal_name] NVARCHAR (128) NULL,
    [database_name]           NVARCHAR (128) NULL,
    [action_name]             NVARCHAR (128) NULL,
    [class_type_desc]         NVARCHAR (128) NULL,
    [securable_class_desc]    NVARCHAR (128) NULL,
    [DDLActionCount]          INT            NULL
);


GO
CREATE CLUSTERED INDEX [idx_rptAggDDLActionsByClass]
    ON [aud].[rptAggDDLActionsByClass]([EventDate] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_ActionName]
    ON [aud].[rptAggDDLActionsByClass]([action_name] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_class_type_desc]
    ON [aud].[rptAggDDLActionsByClass]([class_type_desc] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_Database_name]
    ON [aud].[rptAggDDLActionsByClass]([database_name] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_Instance_Name]
    ON [aud].[rptAggDDLActionsByClass]([server_instance_name] ASC);

