﻿CREATE TABLE [aud].[Statement] (
    [statement_id]   INT             IDENTITY (1, 1) NOT NULL,
    [event_time]     DATETIME2 (7)   NOT NULL,
    [statement_hash] BINARY (64)     NULL,
    [statement_tail] NVARCHAR (400)  NULL,
    [statement]      NVARCHAR (4000) NULL,
    CONSTRAINT [statement_pk] PRIMARY KEY NONCLUSTERED ([statement_id] ASC, [event_time] ASC) ON [monthly_partition_scheme] ([event_time])
) ON [monthly_partition_scheme] ([event_time]);


GO
CREATE UNIQUE CLUSTERED INDEX [cuidx_statement_1]
    ON [aud].[Statement]([statement_hash] ASC, [statement_tail] ASC, [event_time] ASC) WITH (IGNORE_DUP_KEY = ON)
    ON [monthly_partition_scheme] ([event_time]);

