﻿CREATE TABLE [aud].[StatementWorkTable] (
    [statement_id] INT             NOT NULL,
    [event_time]   DATETIME2 (7)   NOT NULL,
    [statement]    NVARCHAR (4000) NULL,
    CONSTRAINT [pk_StatementWorkTable] PRIMARY KEY CLUSTERED ([statement_id] ASC, [event_time] ASC) ON [monthly_partition_scheme] ([event_time])
) ON [monthly_partition_scheme] ([event_time]);

