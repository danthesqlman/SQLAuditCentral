﻿CREATE TABLE [aud].[rptAggDMLActionsByClass] (
    [EventDate]               SMALLDATETIME  NOT NULL,
    [server_instance_name]    NVARCHAR (128) NULL,
    [database_principal_name] NVARCHAR (128) NULL,
    [database_name]           NVARCHAR (128) NULL,
    [action_name]             NVARCHAR (128) NULL,
    [class_type_desc]         NVARCHAR (128) NULL,
    [securable_class_desc]    NVARCHAR (128) NULL,
    [DMLActionCount]          INT            NULL
);


GO
CREATE CLUSTERED INDEX [idx_rptAggDMLActionsByClass]
    ON [aud].[rptAggDMLActionsByClass]([EventDate] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_ActionName]
    ON [aud].[rptAggDMLActionsByClass]([action_name] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_class_type_desc]
    ON [aud].[rptAggDMLActionsByClass]([class_type_desc] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_Database_name]
    ON [aud].[rptAggDMLActionsByClass]([database_name] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_Instance_Name]
    ON [aud].[rptAggDMLActionsByClass]([server_instance_name] ASC);

