﻿CREATE TABLE [aud].[AuditLog_DMLActions] (
    [event_time]                        DATETIME2 (7)   NOT NULL,
    [sequence_number]                   INT             NOT NULL,
    [audited_action_id]                 INT             NOT NULL,
    [audited_class_type_id]             INT             NULL,
    [server_principal_name_id]          INT             NULL,
    [session_server_principal_name_id]  INT             NULL,
    [target_server_principal_name_id]   INT             NULL,
    [database_principal_name_id]        INT             NULL,
    [target_database_principal_name_id] INT             NULL,
    [audited_object_id]                 INT             NULL,
    [succeeded]                         BIT             NULL,
    [permission_bitmask]                BIGINT          NULL,
    [is_column_permission]              BIT             NULL,
    [session_id]                        SMALLINT        NULL,
    [statement_id]                      INT             NULL,
    [additional_information]            NVARCHAR (4000) NULL,
    [audit_file_offset]                 BIGINT          NULL,
    [import_id]                         INT             NULL,
    [audit_file_id]                     INT             NOT NULL,
    [client_address_id]                 INT             NULL,
    [pooled_connection]                 BIT             NULL,
    [packet_data_size]                  INT             NULL,
    [is_dac]                            BIT             NULL,
    [total_cpu]                         INT             NULL,
    [reads]                             INT             NULL,
    [writes]                            INT             NULL,
    [event_count]                       INT             NULL,
    CONSTRAINT [FK_AuditLog_DMLActions_auditedAction] FOREIGN KEY ([audited_action_id]) REFERENCES [aud].[AuditedAction] ([audited_action_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_AuditedClassType] FOREIGN KEY ([audited_class_type_id]) REFERENCES [aud].[AuditedClassType] ([audited_class_type_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_AuditedObject] FOREIGN KEY ([audited_object_id]) REFERENCES [aud].[AuditedObject] ([audited_object_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_AuditFile] FOREIGN KEY ([audit_file_id]) REFERENCES [aud].[AuditFile] ([audit_file_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_ClientAddress] FOREIGN KEY ([client_address_id]) REFERENCES [aud].[ClientAddress] ([client_address_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_DatabasePrincipalName] FOREIGN KEY ([database_principal_name_id]) REFERENCES [aud].[DatabasePrincipalName] ([database_principal_name_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_DatabasePrincipalName1] FOREIGN KEY ([target_database_principal_name_id]) REFERENCES [aud].[DatabasePrincipalName] ([database_principal_name_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_ImportExecution] FOREIGN KEY ([import_id]) REFERENCES [aud].[ImportExecution] ([import_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_ServerPrincipalName] FOREIGN KEY ([server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_ServerPrincipalName1] FOREIGN KEY ([session_server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id]),
    CONSTRAINT [FK_AuditLog_DMLActions_ServerPrincipalName2] FOREIGN KEY ([target_server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id])
) ON [monthly_partition_scheme] ([event_time]);


GO
CREATE CLUSTERED INDEX [cidx_auditlog_DMLActions]
    ON [aud].[AuditLog_DMLActions]([event_time] ASC)
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_aucited_action_id]
    ON [aud].[AuditLog_DMLActions]([audited_action_id] ASC)
    INCLUDE([event_time], [audited_class_type_id], [server_principal_name_id], [database_principal_name_id], [audited_object_id], [statement_id], [client_address_id], [event_count])
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_2]
    ON [aud].[AuditLog_DMLActions]([audited_action_id] ASC, [event_time] ASC)
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_3]
    ON [aud].[AuditLog_DMLActions]([audited_class_type_id] ASC, [event_time] ASC)
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_4]
    ON [aud].[AuditLog_DMLActions]([server_principal_name_id] ASC, [event_time] ASC)
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_5]
    ON [aud].[AuditLog_DMLActions]([session_server_principal_name_id] ASC, [event_time] ASC) WHERE ([session_server_principal_name_id]<>(1))
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_6]
    ON [aud].[AuditLog_DMLActions]([target_server_principal_name_id] ASC, [event_time] ASC) WHERE ([target_server_principal_name_id]<>(1))
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_7]
    ON [aud].[AuditLog_DMLActions]([database_principal_name_id] ASC, [event_time] ASC)
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_8]
    ON [aud].[AuditLog_DMLActions]([target_database_principal_name_id] ASC, [event_time] ASC) WHERE ([target_database_principal_name_id]<>(1))
    ON [monthly_partition_scheme] ([event_time]);


GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_9]
    ON [aud].[AuditLog_DMLActions]([statement_id] ASC, [event_time] ASC)
    ON [monthly_partition_scheme] ([event_time]);

