﻿CREATE TABLE [aud].[AuditedObject] (
    [audited_object_id]    INT            IDENTITY (1, 1) NOT NULL,
    [server_instance_name] NVARCHAR (110) NULL,
    [database_name]        NVARCHAR (110) NULL,
    [schema_name]          NVARCHAR (110) NULL,
    [object_name]          NVARCHAR (110) NULL,
    CONSTRAINT [pk_auditedObject] PRIMARY KEY NONCLUSTERED ([audited_object_id] ASC)
);


GO
CREATE UNIQUE CLUSTERED INDEX [uxc_AuditedObject]
    ON [aud].[AuditedObject]([server_instance_name] ASC, [database_name] ASC, [schema_name] ASC, [object_name] ASC);

