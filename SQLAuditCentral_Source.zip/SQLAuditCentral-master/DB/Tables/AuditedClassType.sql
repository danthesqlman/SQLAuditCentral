﻿CREATE TABLE [aud].[AuditedClassType] (
    [audited_class_type_id] INT           IDENTITY (1, 1) NOT NULL,
    [class_type]            VARCHAR (2)   NOT NULL,
    [class_type_desc]       NVARCHAR (35) NULL,
    [securable_class_desc]  NVARCHAR (25) NULL,
    CONSTRAINT [pk_AuditedClassType] PRIMARY KEY NONCLUSTERED ([audited_class_type_id] ASC)
);


GO
CREATE UNIQUE CLUSTERED INDEX [uxc_AuditedClassType]
    ON [aud].[AuditedClassType]([class_type] ASC);


GO
CREATE UNIQUE NONCLUSTERED INDEX [ux_AuditedClassType]
    ON [aud].[AuditedClassType]([class_type_desc] ASC);

