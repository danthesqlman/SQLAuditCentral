﻿CREATE TABLE [aud].[DatabasePrincipalName] (
    [database_principal_name_id] INT            IDENTITY (1, 1) NOT NULL,
    [database_principal_name]    NVARCHAR (128) NOT NULL,
    CONSTRAINT [pk_DatabasePrincipalName] PRIMARY KEY NONCLUSTERED ([database_principal_name_id] ASC) WITH (IGNORE_DUP_KEY = ON)
);


GO
CREATE UNIQUE CLUSTERED INDEX [uxc_DatabasePrincipalName]
    ON [aud].[DatabasePrincipalName]([database_principal_name] ASC);

GO
CREATE INDEX Database_principal_name on aud.DatabasePrincipalName(database_principal_name)
