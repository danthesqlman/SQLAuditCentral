﻿CREATE TABLE [aud].[rptAggServerActionsByClass] (
    [EventDate]               SMALLDATETIME  NOT NULL,
    [server_instance_name]    NVARCHAR (128) NULL,
    [database_principal_name] NVARCHAR (128) NULL,
    [database_name]           NVARCHAR (128) NULL,
    [action_name]             NVARCHAR (128) NULL,
    [class_type_desc]         NVARCHAR (128) NULL,
    [securable_class_desc]    NVARCHAR (128) NULL,
    [ServerActionCount]       INT            NULL
);


GO
CREATE CLUSTERED INDEX [idx_rptAggServerActionsByClass]
    ON [aud].[rptAggServerActionsByClass]([EventDate] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_ActionName]
    ON [aud].[rptAggServerActionsByClass]([action_name] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_class_type_desc]
    ON [aud].[rptAggServerActionsByClass]([class_type_desc] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_Database_name]
    ON [aud].[rptAggServerActionsByClass]([database_name] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_instance_class_action]
    ON [aud].[rptAggServerActionsByClass]([server_instance_name] ASC, [class_type_desc] ASC, [action_name] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_Instance_Name]
    ON [aud].[rptAggServerActionsByClass]([server_instance_name] ASC);

