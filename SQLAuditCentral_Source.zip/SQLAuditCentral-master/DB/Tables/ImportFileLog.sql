﻿CREATE TABLE [aud].[ImportFileLog] (
    [import_id]            INT            NULL,
    [file_name]            NVARCHAR (512) NULL,
    [last_imported_offset] BIGINT         NULL,
    [log_timestamp]        DATETIME       CONSTRAINT [DF_ImportFileLog_log_timestamp] DEFAULT (getdate()) NULL
);

