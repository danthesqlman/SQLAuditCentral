﻿CREATE TABLE [aud].[rptAggGeneralActionsByClass] (
    [EventDate]               SMALLDATETIME  NOT NULL,
    [server_instance_name]    NVARCHAR (128) NULL,
    [database_principal_name] NVARCHAR (128) NULL,
    [database_name]           NVARCHAR (128) NULL,
    [action_name]             NVARCHAR (128) NULL,
    [class_type_desc]         NVARCHAR (128) NULL,
    [securable_class_desc]    NVARCHAR (128) NULL,
    [ServerActionCount]       INT            NULL
);


GO
CREATE CLUSTERED INDEX [idx_rptAggGeneralActionsByClass]
    ON [aud].[rptAggGeneralActionsByClass]([EventDate] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_instance_class_action]
    ON [aud].[rptAggGeneralActionsByClass]([server_instance_name] ASC, [class_type_desc] ASC, [action_name] ASC);

