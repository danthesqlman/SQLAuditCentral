﻿CREATE TABLE [aud].[ServerPrincipalName] (
    [server_principal_name_id] INT            IDENTITY (1, 1) NOT NULL,
    [server_principal_name]    NVARCHAR (128) NOT NULL,
    [domain_name]              NVARCHAR (128) NULL,
    [principal_name]           NVARCHAR (128) NULL,
    [is_windows_principal]     BIT            NULL,
    CONSTRAINT [pk_ServerPrincipalName] PRIMARY KEY NONCLUSTERED ([server_principal_name_id] ASC) WITH (IGNORE_DUP_KEY = ON)
);


GO
CREATE UNIQUE CLUSTERED INDEX [uxc_ServerPrincipalName]
    ON [aud].[ServerPrincipalName]([server_principal_name] ASC);

