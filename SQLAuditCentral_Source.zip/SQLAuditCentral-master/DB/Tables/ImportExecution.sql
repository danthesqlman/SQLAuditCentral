﻿CREATE TABLE [aud].[ImportExecution] (
    [import_id]    INT            IDENTITY (1, 1) NOT NULL,
    [started_time] DATETIME       NOT NULL,
    [stopped_time] DATETIME       NULL,
    [disposition]  NVARCHAR (128) NULL,
    CONSTRAINT [pk_importexecution] PRIMARY KEY CLUSTERED ([import_id] ASC)
);

