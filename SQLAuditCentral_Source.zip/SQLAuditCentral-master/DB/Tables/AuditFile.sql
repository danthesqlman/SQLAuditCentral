﻿CREATE TABLE [aud].[AuditFile] (
    [audit_file_id]            INT            IDENTITY (1, 1) NOT NULL,
    [audit_file_name]          NVARCHAR (512) NOT NULL,
    [audit_file_name_trimmed]  NVARCHAR (260) NULL,
    [audit_file_path]          NVARCHAR (260) NULL,
    [audit_file_extension]     NVARCHAR (260) NULL,
    [audit_name]               NVARCHAR (128) NULL,
    [audit_guid]               NVARCHAR (50)  NULL,
    [audit_file_partition]     NVARCHAR (10)  NULL,
    [audit_file_timestamp]     NVARCHAR (50)  NULL,
    [audit_file_source_server] NVARCHAR (110) NULL,
    CONSTRAINT [pk_audit_file] PRIMARY KEY NONCLUSTERED ([audit_file_id] ASC)
);

GO
CREATE INDEX Audit_Name on aud.AuditFile(audit_name)