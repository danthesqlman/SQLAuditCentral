﻿CREATE TABLE [aud].[AuditedAction] (
    [audited_action_id] INT            IDENTITY (1, 1) NOT NULL,
    [action_id]         CHAR (4)       NOT NULL,
    [action_name]       NVARCHAR (128) NULL,
    CONSTRAINT [pk_AuditedAction] PRIMARY KEY NONCLUSTERED ([audited_action_id] ASC)
);


GO
CREATE UNIQUE CLUSTERED INDEX [uxc_AuditedAction]
    ON [aud].[AuditedAction]([action_id] ASC);


GO
CREATE NONCLUSTERED INDEX [ux_AuditedAction]
    ON [aud].[AuditedAction]([action_name] ASC);

