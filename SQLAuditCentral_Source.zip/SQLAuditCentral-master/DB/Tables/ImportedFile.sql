﻿CREATE TABLE [aud].[ImportedFile] (
    [imported_file_id]      INT            IDENTITY (1, 1) NOT NULL,
    [import_id]             INT            NOT NULL,
    [file_name]             NVARCHAR (512) NOT NULL,
    [audit_file_offset_min] BIGINT         NOT NULL,
    [audit_file_offset_max] BIGINT         NOT NULL,
    [event_time_min]        DATETIME2 (7)  NOT NULL,
    [event_time_max]        DATETIME2 (7)  NOT NULL,
    [rows_processed]        INT            NOT NULL,
    CONSTRAINT [pk_ImportedFile] PRIMARY KEY CLUSTERED ([imported_file_id] ASC),
    CONSTRAINT [FK_ImportedFile_ImportExecution] FOREIGN KEY ([import_id]) REFERENCES [aud].[ImportExecution] ([import_id])
);

