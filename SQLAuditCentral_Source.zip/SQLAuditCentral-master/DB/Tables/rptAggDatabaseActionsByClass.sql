﻿CREATE TABLE [aud].[rptAggDatabaseActionsByClass] (
    [EventDate]               SMALLDATETIME  NOT NULL,
    [server_instance_name]    NVARCHAR (128) NULL,
    [database_principal_name] NVARCHAR (128) NULL,
    [database_name]           NVARCHAR (128) NULL,
    [action_name]             NVARCHAR (128) NULL,
    [class_type_desc]         NVARCHAR (128) NULL,
    [securable_class_desc]    NVARCHAR (128) NULL,
    [DatabaseActionCount]     INT            NULL
);


GO
CREATE CLUSTERED INDEX [idx_rptAggDatabaseActionsByClass]
    ON [aud].[rptAggDatabaseActionsByClass]([EventDate] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_ActionName]
    ON [aud].[rptAggDatabaseActionsByClass]([action_name] ASC);


GO
CREATE NONCLUSTERED INDEX [Class_Type_Desc]
    ON [aud].[rptAggDatabaseActionsByClass]([class_type_desc] ASC);


GO
CREATE NONCLUSTERED INDEX [Database_Name]
    ON [aud].[rptAggDatabaseActionsByClass]([database_name] ASC);


GO
CREATE NONCLUSTERED INDEX [server_instance_name]
    ON [aud].[rptAggDatabaseActionsByClass]([server_instance_name] ASC);

