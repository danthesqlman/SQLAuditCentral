﻿CREATE TABLE [aud].[ActionGroup_Ref] (
    [ActionGroup]       VARCHAR (50)   NULL,
    [ActionName]        VARCHAR (250)  NULL,
    [ActionDescription] VARCHAR (4000) NULL
);

GO
CREATE INDEX ActionGroup on aud.ActionGroup_Ref(ActionGroup)