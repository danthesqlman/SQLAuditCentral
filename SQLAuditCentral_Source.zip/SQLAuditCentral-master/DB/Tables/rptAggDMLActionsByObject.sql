﻿CREATE TABLE [aud].[rptAggDMLActionsByObject] (
    [EventDate]               SMALLDATETIME  NOT NULL,
    [server_instance_name]    NVARCHAR (128) NULL,
    [database_principal_name] NVARCHAR (128) NULL,
    [database_name]           NVARCHAR (128) NULL,
    [schema_name]             NVARCHAR (128) NULL,
    [object_name]             NVARCHAR (128) NULL,
    [DMLActionCount]          INT            NULL
);


GO
CREATE CLUSTERED INDEX [idx_rptAggDMLActionsByObject]
    ON [aud].[rptAggDMLActionsByObject]([EventDate] ASC);

