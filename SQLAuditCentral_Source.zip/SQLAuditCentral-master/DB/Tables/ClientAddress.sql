﻿CREATE TABLE [aud].[ClientAddress] (
    [client_address_id] INT           IDENTITY (1, 1) NOT NULL,
    [client_address]    NVARCHAR (50) NULL,
    CONSTRAINT [PK_ClientAddress] PRIMARY KEY CLUSTERED ([client_address_id] ASC)
);

