CREATE TABLE [aud].[ImportedFile]
(
[imported_file_id] [int] NOT NULL IDENTITY(1, 1),
[import_id] [int] NOT NULL,
[file_name] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[audit_file_offset_min] [bigint] NOT NULL,
[audit_file_offset_max] [bigint] NOT NULL,
[event_time_min] [datetime2] NOT NULL,
[event_time_max] [datetime2] NOT NULL,
[rows_processed] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[ImportedFile] ADD CONSTRAINT [pk_ImportedFile] PRIMARY KEY CLUSTERED ([imported_file_id]) ON [PRIMARY]
GO
ALTER TABLE [aud].[ImportedFile] WITH NOCHECK ADD CONSTRAINT [FK_ImportedFile_ImportExecution] FOREIGN KEY ([import_id]) REFERENCES [aud].[ImportExecution] ([import_id])
GO
