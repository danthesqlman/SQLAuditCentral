CREATE TABLE [aud].[AuditedClassType]
(
[audited_class_type_id] [int] NOT NULL IDENTITY(1, 1),
[class_type] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[class_type_desc] [nvarchar] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[securable_class_desc] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[AuditedClassType] ADD CONSTRAINT [pk_AuditedClassType] PRIMARY KEY NONCLUSTERED ([audited_class_type_id]) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [uxc_AuditedClassType] ON [aud].[AuditedClassType] ([class_type]) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [ux_AuditedClassType] ON [aud].[AuditedClassType] ([class_type_desc]) ON [PRIMARY]
GO
