CREATE TABLE [aud].[ImportExecution]
(
[import_id] [int] NOT NULL IDENTITY(1, 1),
[started_time] [datetime] NOT NULL,
[stopped_time] [datetime] NULL,
[disposition] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[ImportExecution] ADD CONSTRAINT [pk_importexecution] PRIMARY KEY CLUSTERED ([import_id]) ON [PRIMARY]
GO
