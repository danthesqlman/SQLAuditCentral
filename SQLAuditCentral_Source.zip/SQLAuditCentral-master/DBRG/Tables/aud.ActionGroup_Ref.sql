CREATE TABLE [aud].[ActionGroup_Ref]
(
[ActionGroup] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ActionName] [varchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ActionDescription] [varchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
