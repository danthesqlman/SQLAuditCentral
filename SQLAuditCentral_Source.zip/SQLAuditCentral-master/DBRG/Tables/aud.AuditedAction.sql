CREATE TABLE [aud].[AuditedAction]
(
[audited_action_id] [int] NOT NULL IDENTITY(1, 1),
[action_id] [char] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[action_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[AuditedAction] ADD CONSTRAINT [pk_AuditedAction] PRIMARY KEY NONCLUSTERED ([audited_action_id]) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [uxc_AuditedAction] ON [aud].[AuditedAction] ([action_id]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [ux_AuditedAction] ON [aud].[AuditedAction] ([action_name]) ON [PRIMARY]
GO
