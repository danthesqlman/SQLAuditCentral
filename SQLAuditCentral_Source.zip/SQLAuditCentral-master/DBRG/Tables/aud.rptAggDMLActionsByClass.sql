CREATE TABLE [aud].[rptAggDMLActionsByClass]
(
[EventDate] [smalldatetime] NOT NULL,
[server_instance_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[action_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[class_type_desc] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[securable_class_desc] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DMLActionCount] [int] NULL
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_ActionName] ON [aud].[rptAggDMLActionsByClass] ([action_name]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_class_type_desc] ON [aud].[rptAggDMLActionsByClass] ([class_type_desc]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_Database_name] ON [aud].[rptAggDMLActionsByClass] ([database_name]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [idx_rptAggDMLActionsByClass] ON [aud].[rptAggDMLActionsByClass] ([EventDate]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_Instance_Name] ON [aud].[rptAggDMLActionsByClass] ([server_instance_name]) ON [PRIMARY]
GO
