CREATE TABLE [aud].[AuditedObject]
(
[audited_object_id] [int] NOT NULL IDENTITY(1, 1),
[server_instance_name] [nvarchar] (110) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_name] [nvarchar] (110) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[schema_name] [nvarchar] (110) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[object_name] [nvarchar] (110) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[AuditedObject] ADD CONSTRAINT [pk_auditedObject] PRIMARY KEY NONCLUSTERED ([audited_object_id]) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [uxc_AuditedObject] ON [aud].[AuditedObject] ([server_instance_name], [database_name], [schema_name], [object_name]) ON [PRIMARY]
GO
