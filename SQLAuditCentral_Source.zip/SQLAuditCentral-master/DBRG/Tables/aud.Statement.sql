CREATE TABLE [aud].[Statement]
(
[statement_id] [int] NOT NULL IDENTITY(1, 1),
[event_time] [datetime2] NOT NULL,
[statement_hash] [binary] (64) NULL,
[statement_tail] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[statement] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [monthly_partition_scheme] ([event_time])
GO
ALTER TABLE [aud].[Statement] ADD CONSTRAINT [statement_pk] PRIMARY KEY NONCLUSTERED ([statement_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE UNIQUE CLUSTERED INDEX [cuidx_statement_1] ON [aud].[Statement] ([statement_hash], [statement_tail], [event_time]) WITH (IGNORE_DUP_KEY=ON) ON [monthly_partition_scheme] ([event_time])
GO
