CREATE TABLE [aud].[StatementWorkTable]
(
[statement_id] [int] NOT NULL,
[event_time] [datetime2] NOT NULL,
[statement] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [monthly_partition_scheme] ([event_time])
GO
ALTER TABLE [aud].[StatementWorkTable] ADD CONSTRAINT [pk_StatementWorkTable] PRIMARY KEY CLUSTERED ([statement_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
