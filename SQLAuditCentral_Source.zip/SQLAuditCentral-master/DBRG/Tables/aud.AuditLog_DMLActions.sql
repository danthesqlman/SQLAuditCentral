CREATE TABLE [aud].[AuditLog_DMLActions]
(
[event_time] [datetime2] NOT NULL,
[sequence_number] [int] NOT NULL,
[audited_action_id] [int] NOT NULL,
[audited_class_type_id] [int] NULL,
[server_principal_name_id] [int] NULL,
[session_server_principal_name_id] [int] NULL,
[target_server_principal_name_id] [int] NULL,
[database_principal_name_id] [int] NULL,
[target_database_principal_name_id] [int] NULL,
[audited_object_id] [int] NULL,
[succeeded] [bit] NULL,
[permission_bitmask] [bigint] NULL,
[is_column_permission] [bit] NULL,
[session_id] [smallint] NULL,
[statement_id] [int] NULL,
[additional_information] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_file_offset] [bigint] NULL,
[import_id] [int] NULL,
[audit_file_id] [int] NOT NULL,
[client_address_id] [int] NULL,
[pooled_connection] [bit] NULL,
[packet_data_size] [int] NULL,
[is_dac] [bit] NULL,
[total_cpu] [int] NULL,
[reads] [int] NULL,
[writes] [int] NULL,
[event_count] [int] NULL
) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_aucited_action_id] ON [aud].[AuditLog_DMLActions] ([audited_action_id]) INCLUDE ([event_time], [audited_class_type_id], [server_principal_name_id], [database_principal_name_id], [audited_object_id], [statement_id], [client_address_id], [event_count]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_2] ON [aud].[AuditLog_DMLActions] ([audited_action_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_3] ON [aud].[AuditLog_DMLActions] ([audited_class_type_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_7] ON [aud].[AuditLog_DMLActions] ([database_principal_name_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE CLUSTERED INDEX [cidx_auditlog_DMLActions] ON [aud].[AuditLog_DMLActions] ([event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_DMLActions_4] ON [aud].[AuditLog_DMLActions] ([server_principal_name_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_5] ON [aud].[AuditLog_DMLActions] ([session_server_principal_name_id], [event_time]) WHERE ([session_server_principal_name_id]<>(1)) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_9] ON [aud].[AuditLog_DMLActions] ([statement_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_8] ON [aud].[AuditLog_DMLActions] ([target_database_principal_name_id], [event_time]) WHERE ([target_database_principal_name_id]<>(1)) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_dmlactions_6] ON [aud].[AuditLog_DMLActions] ([target_server_principal_name_id], [event_time]) WHERE ([target_server_principal_name_id]<>(1)) ON [monthly_partition_scheme] ([event_time])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_auditedAction] FOREIGN KEY ([audited_action_id]) REFERENCES [aud].[AuditedAction] ([audited_action_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_AuditedClassType] FOREIGN KEY ([audited_class_type_id]) REFERENCES [aud].[AuditedClassType] ([audited_class_type_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_AuditedObject] FOREIGN KEY ([audited_object_id]) REFERENCES [aud].[AuditedObject] ([audited_object_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_AuditFile] FOREIGN KEY ([audit_file_id]) REFERENCES [aud].[AuditFile] ([audit_file_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_ClientAddress] FOREIGN KEY ([client_address_id]) REFERENCES [aud].[ClientAddress] ([client_address_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_DatabasePrincipalName] FOREIGN KEY ([database_principal_name_id]) REFERENCES [aud].[DatabasePrincipalName] ([database_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_DatabasePrincipalName1] FOREIGN KEY ([target_database_principal_name_id]) REFERENCES [aud].[DatabasePrincipalName] ([database_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_ImportExecution] FOREIGN KEY ([import_id]) REFERENCES [aud].[ImportExecution] ([import_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_ServerPrincipalName] FOREIGN KEY ([server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_ServerPrincipalName1] FOREIGN KEY ([session_server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DMLActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DMLActions_ServerPrincipalName2] FOREIGN KEY ([target_server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id])
GO
