CREATE TABLE [aud].[rptAggDatabaseActionsByClass]
(
[EventDate] [smalldatetime] NOT NULL,
[server_instance_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[action_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[class_type_desc] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[securable_class_desc] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DatabaseActionCount] [int] NULL
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_ActionName] ON [aud].[rptAggDatabaseActionsByClass] ([action_name]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_class_type_desc] ON [aud].[rptAggDatabaseActionsByClass] ([class_type_desc]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_Database_name] ON [aud].[rptAggDatabaseActionsByClass] ([database_name]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [idx_rptAggDatabaseActionsByClass] ON [aud].[rptAggDatabaseActionsByClass] ([EventDate]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_Instance_Name] ON [aud].[rptAggDatabaseActionsByClass] ([server_instance_name]) ON [PRIMARY]
GO
