CREATE TABLE [aud].[AuditFile]
(
[audit_file_id] [int] NOT NULL IDENTITY(1, 1),
[audit_file_name] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[audit_file_name_trimmed] [nvarchar] (260) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_file_path] [nvarchar] (260) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_file_extension] [nvarchar] (260) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_guid] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_file_partition] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_file_timestamp] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_file_source_server] [nvarchar] (110) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[AuditFile] ADD CONSTRAINT [pk_audit_file] PRIMARY KEY NONCLUSTERED ([audit_file_id]) ON [PRIMARY]
GO
