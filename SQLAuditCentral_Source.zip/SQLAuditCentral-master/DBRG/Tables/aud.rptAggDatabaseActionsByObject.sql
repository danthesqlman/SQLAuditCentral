CREATE TABLE [aud].[rptAggDatabaseActionsByObject]
(
[EventDate] [smalldatetime] NOT NULL,
[server_instance_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[schema_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[object_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DatabaseActionCount] [int] NULL
) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [idx_rptAggDatabaseActionsByObject] ON [aud].[rptAggDatabaseActionsByObject] ([EventDate]) ON [PRIMARY]
GO
