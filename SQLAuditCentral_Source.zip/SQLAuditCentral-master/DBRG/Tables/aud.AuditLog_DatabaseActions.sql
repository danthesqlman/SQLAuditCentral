CREATE TABLE [aud].[AuditLog_DatabaseActions]
(
[event_time] [datetime2] NOT NULL,
[sequence_number] [int] NOT NULL,
[audited_action_id] [int] NOT NULL,
[audited_class_type_id] [int] NULL,
[server_principal_name_id] [int] NULL,
[session_server_principal_name_id] [int] NULL,
[target_server_principal_name_id] [int] NULL,
[database_principal_name_id] [int] NULL,
[target_database_principal_name_id] [int] NULL,
[audited_object_id] [int] NULL,
[succeeded] [bit] NULL,
[permission_bitmask] [bigint] NULL,
[is_column_permission] [bit] NULL,
[session_id] [smallint] NULL,
[statement_id] [int] NULL,
[additional_information] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[audit_file_offset] [bigint] NULL,
[import_id] [int] NULL,
[audit_file_id] [int] NOT NULL,
[client_address_id] [int] NULL,
[pooled_connection] [bit] NULL,
[packet_data_size] [int] NULL,
[is_dac] [bit] NULL,
[total_cpu] [int] NULL,
[reads] [int] NULL,
[writes] [int] NULL,
[event_count] [int] NULL
) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_2] ON [aud].[AuditLog_DatabaseActions] ([audited_action_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_3] ON [aud].[AuditLog_DatabaseActions] ([audited_class_type_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_7] ON [aud].[AuditLog_DatabaseActions] ([database_principal_name_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE CLUSTERED INDEX [cidx_auditlog_databaseactions] ON [aud].[AuditLog_DatabaseActions] ([event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_4] ON [aud].[AuditLog_DatabaseActions] ([server_principal_name_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_5] ON [aud].[AuditLog_DatabaseActions] ([session_server_principal_name_id], [event_time]) WHERE ([session_server_principal_name_id]<>(1)) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_9] ON [aud].[AuditLog_DatabaseActions] ([statement_id], [event_time]) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_8] ON [aud].[AuditLog_DatabaseActions] ([target_database_principal_name_id], [event_time]) WHERE ([target_database_principal_name_id]<>(1)) ON [monthly_partition_scheme] ([event_time])
GO
CREATE NONCLUSTERED INDEX [idx_auditlog_databaseactions_6] ON [aud].[AuditLog_DatabaseActions] ([target_server_principal_name_id], [event_time]) WHERE ([target_server_principal_name_id]<>(1)) ON [monthly_partition_scheme] ([event_time])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_auditedAction] FOREIGN KEY ([audited_action_id]) REFERENCES [aud].[AuditedAction] ([audited_action_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_AuditedClassType] FOREIGN KEY ([audited_class_type_id]) REFERENCES [aud].[AuditedClassType] ([audited_class_type_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_AuditedObject] FOREIGN KEY ([audited_object_id]) REFERENCES [aud].[AuditedObject] ([audited_object_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_AuditFile] FOREIGN KEY ([audit_file_id]) REFERENCES [aud].[AuditFile] ([audit_file_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_ClientAddress] FOREIGN KEY ([client_address_id]) REFERENCES [aud].[ClientAddress] ([client_address_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_DatabasePrincipalName] FOREIGN KEY ([database_principal_name_id]) REFERENCES [aud].[DatabasePrincipalName] ([database_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_DatabasePrincipalName1] FOREIGN KEY ([target_database_principal_name_id]) REFERENCES [aud].[DatabasePrincipalName] ([database_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_ImportExecution] FOREIGN KEY ([import_id]) REFERENCES [aud].[ImportExecution] ([import_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_ServerPrincipalName] FOREIGN KEY ([server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_ServerPrincipalName1] FOREIGN KEY ([target_server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id])
GO
ALTER TABLE [aud].[AuditLog_DatabaseActions] WITH NOCHECK ADD CONSTRAINT [FK_AuditLog_DatabaseActions_ServerPrincipalName2] FOREIGN KEY ([session_server_principal_name_id]) REFERENCES [aud].[ServerPrincipalName] ([server_principal_name_id])
GO
