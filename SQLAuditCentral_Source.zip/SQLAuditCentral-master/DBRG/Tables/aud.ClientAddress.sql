CREATE TABLE [aud].[ClientAddress]
(
[client_address_id] [int] NOT NULL IDENTITY(1, 1),
[client_address] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[ClientAddress] ADD CONSTRAINT [PK_ClientAddress] PRIMARY KEY CLUSTERED ([client_address_id]) ON [PRIMARY]
GO
