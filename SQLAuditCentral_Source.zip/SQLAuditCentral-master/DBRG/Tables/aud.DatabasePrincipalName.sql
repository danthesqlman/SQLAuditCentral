CREATE TABLE [aud].[DatabasePrincipalName]
(
[database_principal_name_id] [int] NOT NULL IDENTITY(1, 1),
[database_principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[DatabasePrincipalName] ADD CONSTRAINT [pk_DatabasePrincipalName] PRIMARY KEY NONCLUSTERED ([database_principal_name_id]) WITH (IGNORE_DUP_KEY=ON) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [uxc_DatabasePrincipalName] ON [aud].[DatabasePrincipalName] ([database_principal_name]) ON [PRIMARY]
GO
