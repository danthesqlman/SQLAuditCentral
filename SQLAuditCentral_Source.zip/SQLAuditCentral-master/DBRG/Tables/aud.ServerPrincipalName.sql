CREATE TABLE [aud].[ServerPrincipalName]
(
[server_principal_name_id] [int] NOT NULL IDENTITY(1, 1),
[server_principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[domain_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[is_windows_principal] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [aud].[ServerPrincipalName] ADD CONSTRAINT [pk_ServerPrincipalName] PRIMARY KEY NONCLUSTERED ([server_principal_name_id]) WITH (IGNORE_DUP_KEY=ON) ON [PRIMARY]
GO
CREATE UNIQUE CLUSTERED INDEX [uxc_ServerPrincipalName] ON [aud].[ServerPrincipalName] ([server_principal_name]) ON [PRIMARY]
GO
