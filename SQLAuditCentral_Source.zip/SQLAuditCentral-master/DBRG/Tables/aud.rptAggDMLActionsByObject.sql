CREATE TABLE [aud].[rptAggDMLActionsByObject]
(
[EventDate] [smalldatetime] NOT NULL,
[server_instance_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[schema_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[object_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DMLActionCount] [int] NULL
) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [idx_rptAggDMLActionsByObject] ON [aud].[rptAggDMLActionsByObject] ([EventDate]) ON [PRIMARY]
GO
