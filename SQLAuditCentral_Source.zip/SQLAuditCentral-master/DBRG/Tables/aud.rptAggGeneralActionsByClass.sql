CREATE TABLE [aud].[rptAggGeneralActionsByClass]
(
[EventDate] [smalldatetime] NOT NULL,
[server_instance_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_principal_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[database_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[action_name] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[class_type_desc] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[securable_class_desc] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ServerActionCount] [int] NULL
) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [idx_rptAggGeneralActionsByClass] ON [aud].[rptAggGeneralActionsByClass] ([EventDate]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [idx_instance_class_action] ON [aud].[rptAggGeneralActionsByClass] ([server_instance_name], [class_type_desc], [action_name]) ON [PRIMARY]
GO
