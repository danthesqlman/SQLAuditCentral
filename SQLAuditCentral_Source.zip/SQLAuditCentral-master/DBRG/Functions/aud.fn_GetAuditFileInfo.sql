SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
Create FUNCTION [aud].[fn_GetAuditFileInfo]
(@audit_file_name NVARCHAR (512))
RETURNS TABLE 
AS
RETURN 

-- Look for last 3 occurance of '_' to identify TimeStamp, PartitionID, Guid and File name then reverse them again
    (
	select audit_name = Reverse(RIGHT(audit_file_name_trimmed, len(audit_file_name_trimmed) - us3))
			, audit_guid = Reverse(SUBSTRING(audit_file_name_trimmed, us2 + 1, us3 - us2 - 1))
			, audit_file_partition = Reverse(SUBSTRING(audit_file_name_trimmed, us1 + 1, us2 - us1 - 1))
			, audit_file_timestamp = Reverse(LEFT(audit_file_name_trimmed, us1 - 1))
			, audit_file_name
			, Reverse(audit_file_name_trimmed) AS audit_file_name_trimmed
			, audit_file_path
			, audit_file_extension
	  from (
		select audit_file_name
				, audit_file_name_trimmed
				, audit_file_path
				, audit_file_extension
				, us1 = CHARINDEX('_', audit_file_name_trimmed)
				, us2 = CHARINDEX('_', audit_file_name_trimmed, CHARINDEX('_', audit_file_name_trimmed) + 1)
				, us3 = CHARINDEX('_', audit_file_name_trimmed, CHARINDEX('_', audit_file_name_trimmed, CHARINDEX('_', audit_file_name_trimmed) + 1) + 1)
		  from (
			select audit_file_name = @audit_file_name
					, audit_file_name_trimmed = reverse(LEFT(RIGHT(@audit_file_name, CHARINDEX('\', reverse(@audit_file_name))-1), CHARINDEX('.', RIGHT(@audit_file_name, CHARINDEX('\', reverse(@audit_file_name))-1), 1) - 1))
					, audit_file_path = LEFT(@audit_file_name, len(@audit_file_name) - CHARINDEX('\', reverse(@audit_file_name)))
					, audit_file_extension = RIGHT(@audit_file_name, CHARINDEX('.', reverse(@audit_file_name))-1)
		  ) a
		) b
)
GO
