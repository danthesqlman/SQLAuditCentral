SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [aud].[fn_GetAuditFileInfo_OLD]
(@audit_file_name NVARCHAR (512))
RETURNS TABLE 
AS
RETURN 
    (
	select audit_name = LEFT(audit_file_name_trimmed, us1 - 1)
			, audit_guid = SUBSTRING(audit_file_name_trimmed, us1 + 1, us2 - us1 - 1)
			, audit_file_partition = SUBSTRING(audit_file_name_trimmed, us2 + 1, us3 - us2 - 1)
			, audit_file_timestamp = RIGHT(audit_file_name_trimmed, len(audit_file_name_trimmed) - us3)
			, audit_file_name
			, audit_file_name_trimmed
			, audit_file_path
			, audit_file_extension
	  from (
		select audit_file_name
				, audit_file_name_trimmed
				, audit_file_path
				, audit_file_extension
				, us1 = CHARINDEX('_', audit_file_name_trimmed)
				, us2 = CHARINDEX('_', audit_file_name_trimmed, CHARINDEX('_', audit_file_name_trimmed) + 1)
				, us3 = CHARINDEX('_', audit_file_name_trimmed, CHARINDEX('_', audit_file_name_trimmed, CHARINDEX('_', audit_file_name_trimmed) + 1) + 1)
		  from (
			select audit_file_name = @audit_file_name
					, audit_file_name_trimmed = LEFT(RIGHT(@audit_file_name, CHARINDEX('\', reverse(@audit_file_name))-1), CHARINDEX('.', RIGHT(@audit_file_name, CHARINDEX('\', reverse(@audit_file_name))-1), 1) - 1)
					, audit_file_path = LEFT(@audit_file_name, len(@audit_file_name) - CHARINDEX('\', reverse(@audit_file_name)))
					, audit_file_extension = RIGHT(@audit_file_name, CHARINDEX('.', reverse(@audit_file_name))-1)
		  ) a
		) b
)
GO
