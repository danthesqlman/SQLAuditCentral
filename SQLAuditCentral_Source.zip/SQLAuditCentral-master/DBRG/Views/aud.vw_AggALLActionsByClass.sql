SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE View [aud].[vw_AggALLActionsByClass]
AS
Select z.EventDate, z.server_instance_name, z.database_principal_name, z.database_name, z.action_name,
        z.class_type_desc, z.securable_class_desc, z.ActionCount, z.ActionSource
From 
(Select EventDate, server_instance_name, database_principal_name, database_name, action_name,
        class_type_desc, securable_class_desc, ServerActionCount AS ActionCount,'SRV' AS ActionSource
 From aud.rptAggServerActionsByClass
 UNION ALL
 Select EventDate, server_instance_name, database_principal_name, database_name, action_name,
        class_type_desc, securable_class_desc, DatabaseActionCount AS ActionCount,'DB' AS ActionSource
 From aud.rptAggDatabaseActionsByClass
 UNION ALL
 Select EventDate, server_instance_name, database_principal_name, database_name, action_name,
        class_type_desc, securable_class_desc, DDLActionCount AS ActionCount,'DDL' AS ActionSource
 From aud.rptAggDDLActionsByClass
 UNION ALL
 Select EventDate, server_instance_name, database_principal_name, database_name, action_name,
        class_type_desc, securable_class_desc, DMLActionCount AS ActionCount, 'DML' AS ActionSource
 From aud.rptAggDMLActionsByClass
  
 ) z
GO
