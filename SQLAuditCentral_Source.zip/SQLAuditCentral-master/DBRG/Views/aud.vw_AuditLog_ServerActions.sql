SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
create view [aud].[vw_AuditLog_ServerActions]
as
select 
	f.event_time,
	f.sequence_number,
	--f.audited_action_id,
	a.action_id,
	a.action_name,
	--f.audited_class_type_id,
	b.class_type_desc, 
	b.securable_class_desc,
	--f.server_principal_name_id,
	c.server_principal_name,
	--f.session_server_principal_name_id,
	d.server_principal_name as session_server_principal_name,
	--f.target_server_principal_name_id,
	e.server_principal_name as target_server_principal_name,
	--f.database_principal_name_id,
	g.database_principal_name,
	--f.target_database_principal_name_id,
	h.database_principal_name as target_database_principal_name,
	--f.audited_object_id,
	i.server_instance_name, 
	i.database_name, 
	i.[schema_name], 
	i.[object_name],
	f.succeeded,
	f.permission_bitmask,
	f.is_column_permission,
	f.session_id,
	s.[statement],
	f.additional_information,
	f.audit_file_offset,
	f.import_id,
	f.audit_file_id,
	--f.client_address_id,
	j.client_address,
	f.pooled_connection,
	f.packet_data_size,
	f.is_dac,
	f.total_cpu,
	f.reads,
	f.writes
from [aud].[AuditLog_ServerActions] f
	left outer join aud.auditedAction a
		on a.audited_action_id = f.audited_action_id
	left outer join aud.AuditedClassType b
		on b.audited_class_type_id = f.audited_class_type_id
	left outer join aud.ServerPrincipalName c
		on c.server_principal_name_id = f.server_principal_name_id
	left outer join aud.ServerPrincipalName d
		on d.server_principal_name_id = f.session_server_principal_name_id
	left outer join aud.ServerPrincipalName e
		on e.server_principal_name_id = f.target_server_principal_name_id
	left outer join aud.DatabasePrincipalName g
		on g.database_principal_name_id = f.database_principal_name_id 
	left outer join aud.DatabasePrincipalName h
		on g.database_principal_name_id = f.target_database_principal_name_id 
	left outer join aud.AuditedObject i
		on i.audited_object_id = f.audited_object_id
	left outer join aud.ClientAddress j
		on j.client_address_id = f.client_address_id
	left outer join aud.[Statement] s
		on s.statement_id = f.statement_id
GO
