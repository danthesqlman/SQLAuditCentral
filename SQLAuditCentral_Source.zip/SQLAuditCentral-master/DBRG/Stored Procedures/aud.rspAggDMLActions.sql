SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE procedure [aud].[rspAggDMLActions](
	@EventDate smalldatetime = null
)
as
begin
	/* Dev Notes: 
		- probably should go into partitioned tables so can drop partition instead of deleting data
		- probably should put transactions around this to protect data */

	-- optimization
	set nocount on
	
	-- set date
	-- assumes you want to process the previous days' data
	Declare @TimeDiff int


    -- Get the difference between Local Time and UTC time
    Select @TimeDiff = DATEDIFF(hh,GETUTCDATE(),GETDATE())
    
	if @EventDate is null set @EventDate = cast(cast(dateadd(dd, -1, GETDATE()) as varchar(11)) as smalldatetime)

	Select @EventDate

	/* DML Actions by Date, Instance, Principal, Object */
	-- delete data with this date
	delete from [aud].[rptAggDMLActionsByObject] where EventDate = @EventDate
	
	-- populate date with this date
	insert into [aud].[rptAggDMLActionsByObject]
	select
		z.EventDate,
		i.server_instance_name, 
		g.database_principal_name,
		i.database_name, 
		i.[schema_name], 
		i.[object_name],
		z.DMLActionCount
	from (
			select 
				cast(CAST(DATEADD(hh,@TimeDiff,event_time) as varchar(11)) as smalldatetime) as EventDate, 
				audited_object_id,
				database_principal_name_id,
				sum(event_count) as DMLActionCount
			from aud.AuditLog_DMLActions
			where cast(CAST(DATEADD(hh,@TimeDiff,event_time) as varchar(11)) as smalldatetime) = @EventDate
			group by 
				cast(CAST(DATEADD(hh,@TimeDiff,event_time) as varchar(11)) as smalldatetime), 
				audited_object_id,
				database_principal_name_id
	) z
	left outer join aud.AuditedObject i
		on i.audited_object_id = z.audited_object_id
	left outer join aud.DatabasePrincipalName g
		on g.database_principal_name_id = z.database_principal_name_id 
		
 
	/* DML Actions by Class */
	-- delete data with this date
	delete from aud.rptAggDMLActionsByClass where EventDate = @EventDate
	
	-- populate date with this date
	insert into [aud].[rptAggDMLActionsByClass]
	select 
		z.EventDate,
		i.server_instance_name, 	
		g.database_principal_name,
		i.database_name,
		a.action_name,
		b.class_type_desc,
		b.securable_class_desc,
		z.DMLActionCount
	from (	
		select 
			cast(CAST(DATEADD(hh,@TimeDiff,event_time) as varchar(11)) as smalldatetime) as EventDate, 
			audited_object_id,		
			database_principal_name_id,		
			audited_action_id,
			audited_class_type_id,
			sum(event_count) as DMLActionCount
		from aud.AuditLog_DMLActions
		where cast(CAST(DATEADD(hh,@TimeDiff,event_time) as varchar(11)) as smalldatetime) = @EventDate
		group by 
			cast(CAST(DATEADD(hh,@TimeDiff,event_time) as varchar(11)) as smalldatetime), 
			audited_object_id,		
			database_principal_name_id,		
			audited_action_id,
			audited_class_type_id
	) z
	left outer join aud.AuditedObject i
		on i.audited_object_id = z.audited_object_id
	left outer join aud.DatabasePrincipalName g
		on g.database_principal_name_id = z.database_principal_name_id 
	left outer join aud.auditedAction a
		on a.audited_action_id = z.audited_action_id
	left outer join aud.AuditedClassType b
		on b.audited_class_type_id = z.audited_class_type_id

end
GO
