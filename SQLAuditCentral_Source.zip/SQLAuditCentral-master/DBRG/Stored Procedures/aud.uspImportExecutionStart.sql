SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [aud].[uspImportExecutionStart]
@import_id INT OUTPUT
AS
SET NOCOUNT ON;

INSERT INTO aud.ImportExecution (
	started_time
	) 
	VALUES (
		getdate()
		);

SET @import_id = SCOPE_IDENTITY();
GO
