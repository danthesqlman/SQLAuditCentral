SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [aud].[uspUpdateStatementEventTimes]

AS
declare @min_event_time datetime2(7)
		, @max_event_time datetime2(7);

with first_range_cte as (
select top 2 prv.value
  from sys.partition_range_values prv
  join sys.partition_functions pf
    on prv.function_id = pf.function_id
 where name = 'monthly_partition_function'
 order by value
)
select @min_event_time = MIN(cast(value as datetime2(7))), @max_event_time = MAX(cast(value as datetime2(7))) from first_range_cte;
 


with statements_cte as (
select statement_id, event_time
  from aud.Statement
 where event_time between @min_event_time and @max_event_time
 )
update s
   set event_time = act.event_time
  from statements_cte s
  join (
	select statement_id, event_time = MAX(event_time)
	  from (
		select act.statement_id, event_time = MAX(act.event_time)
		  from aud.AuditLog_ServerActions act
		  join statements_cte 
			on act.statement_id = statements_cte.statement_id
		  group by act.statement_id
		UNION  
		select act.statement_id, event_time = MAX(act.event_time)
		  from aud.AuditLog_DatabaseActions act
		  join statements_cte 
			on act.statement_id = statements_cte.statement_id
		  group by act.statement_id
		UNION  
		select act.statement_id, event_time = MAX(act.event_time)
		  from aud.AuditLog_DDLActions act
		  join statements_cte 
			on act.statement_id = statements_cte.statement_id
		  group by act.statement_id
		UNION  
		select act.statement_id, event_time = MAX(act.event_time)
		  from aud.AuditLog_DMLActions act
		  join statements_cte 
			on act.statement_id = statements_cte.statement_id
		  group by act.statement_id
	  ) act
	  group by act.statement_id
	 ) act
	on s.statement_id = act.statement_id
GO
