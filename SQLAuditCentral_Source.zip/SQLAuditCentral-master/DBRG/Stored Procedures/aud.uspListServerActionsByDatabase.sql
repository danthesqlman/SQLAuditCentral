SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE Procedure [aud].[uspListServerActionsByDatabase]  
@Instance_name nvarchar(128), @DB_Name nvarchar(128), @StartTime smalldatetime, @EndTime smalldatetime
AS

/*

List Server Actions by Instance and Database name

*/
     
Declare @TimeDiff int

Select @TimeDiff = DATEDIFF(hh,GETUTCDATE(),GETDATE())
     
SELECT S1.event_time AS UTC_Time, DATEADD(hh,@TimeDiff,S1.event_time) AS event_time, 
A.action_name, C1.class_type_desc, O.object_name, 
O.schema_name, C2.client_address, D2.database_principal_name, 
S2.server_principal_name, S3.statement
FROM aud.auditlog_Serveractions S1 
join aud.auditedAction A on S1.audited_action_id = A.audited_action_id
join aud.AuditedClassType C1 on S1.audited_class_type_id = C1.audited_class_type_id
join aud.AuditedObject O on S1.audited_object_id = O.audited_object_id
join aud.ClientAddress C2 on S1.client_address_id = C2.client_address_id
join aud.DatabasePrincipalName D2 on S1.database_principal_name_id = D2.database_principal_name_id
join aud.ServerPrincipalName S2 on S1.server_principal_name_id = S2.server_principal_name_id
join aud.Statement S3 on S1.statement_id = S3.statement_id
Where O.server_instance_name = @Instance_name AND o.database_name = @DB_Name
AND DATEADD(hh,@TimeDiff,S1.event_time) >= @StartTime AND DATEADD(hh,@TimeDiff,S1.event_time) <= @EndTime
order by S1.event_time
GO
