SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[spADD_PARTITION_RIGHT_ON_AuditLog]
AS

DECLARE @month datetime, @fg char(14),@mm char(2), @str varchar(1000)

SET @month = cast((select top 1 [value] from sys.partition_range_values
       where function_id = (select function_id 
               from sys.partition_functions
               where name = 'monthly_partition_function')
      order by boundary_id DESC) as datetime)

SET @month = DATEADD(month, 1, @month)

Print @month

If datepart(mm,@month) < 10
  Set @mm = '0'+Cast(datepart(mm,@month) as CHAR(2))
Else
  Set @mm = Cast(datepart(mm,@month) as CHAR(2))

Set @fg = 'fgAuditMonth'+@mm

Print @fg

Set @str = 'ALTER PARTITION SCHEME monthly_partition_scheme NEXT USED ['+@fg+']';

Print @str

Execute (@str)

ALTER PARTITION FUNCTION monthly_partition_function() 
SPLIT RANGE (@month);
GO
