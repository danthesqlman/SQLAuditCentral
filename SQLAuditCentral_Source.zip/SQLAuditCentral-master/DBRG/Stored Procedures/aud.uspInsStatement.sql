SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [aud].[uspInsStatement]
@statement_hash BINARY (64), @statement_tail NVARCHAR (400)
AS
SET NOCOUNT ON ;

DECLARE @new_statement_ids TABLE (statement_id int) ;

WITH statementcte AS (
	SELECT statement_hash = @statement_hash
			, statement_tail = @statement_tail
	)
MERGE aud.Statement AS target
USING statementcte AS source 
   ON (     target.statement_hash = source.statement_hash
		AND target.statement_tail = source.statement_tail
		)
 WHEN NOT MATCHED THEN 
	INSERT (statement_hash, statement_tail, event_time)
	VALUES (statement_hash, statement_tail, '1/1/2000')
output inserted.statement_id into @new_statement_ids
	;

SELECT statement_id
		, statement_hash
		, statement_tail
		, is_new_statement = CAST(
				case 
					when exists(select top 1 1 from @new_statement_ids) then 1 
					else 0 
				end
				as bit)
				
  FROM aud.Statement
 WHERE statement_hash = @statement_hash
   AND statement_tail = @statement_tail
GO
