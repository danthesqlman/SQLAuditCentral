SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [aud].[uspImportedFileGetLastImportedOffset]
@file_name NVARCHAR (260), @file_offset BIGINT OUTPUT
AS
select @file_name = RTRIM(ltrim(@file_name))

declare @audit_guid uniqueidentifier
		, @audit_file_timestamp bigint
		, @audit_file_name_trimmed nvarchar(260)

select @audit_guid  = audit_guid
		, @audit_file_timestamp = audit_file_timestamp
		, @audit_file_name_trimmed = audit_file_name_trimmed
	  from aud.fn_GetAuditFileInfo(@file_name)


if exists(
	select top 1 1 
	  from aud.AuditFile
	 where audit_guid = @audit_guid
	   and audit_file_timestamp > @audit_file_timestamp
	   )
	   and exists (
	   select top 1 1 
	     from aud.AuditFile
	    where audit_file_name_trimmed = @audit_file_name_trimmed
	    )
begin
	SELECT @file_offset = -1
end
else
begin
	SELECT @file_offset = isnull(max(audit_file_offset_max), 0)
	  FROM aud.ImportedFile
	 WHERE file_name = @file_name
end
If @file_offset = 0
   Select @file_offset = min(audit_file_offset)
   From sys.fn_get_audit_file(@file_name, null, null)
GO
