SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [aud].[uspInsAuditedAction]
@action_id VARCHAR (4)
AS
SET NOCOUNT ON;

WITH actioncte AS (
	SELECT DISTINCT action_id
			, name as action_name 
	  FROM sys.dm_audit_actions 
	 WHERE action_id = RTRIM(LTRIM(@action_id))
	)
MERGE aud.auditedAction AS target
USING actioncte AS source 
   ON (target.action_id = source.action_id)
 WHEN NOT MATCHED THEN 
	INSERT (action_id, action_name)
	VALUES (action_id, action_name)
	;

SELECT * 
  FROM aud.AuditedAction 
 WHERE action_id = @action_id
GO
