SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
Create Procedure [aud].[uspListDDLActionsByPrincipal]
     @Instance_name nvarchar(128), @Principal_name nvarchar(128) , @StartTime smalldatetime, @EndTime smalldatetime
AS

/*

List DDl Actions by Instance by Principal

*/

Declare @pString nvarchar(130)
     
Declare @TimeDiff int

Set @pString = '%'+@Principal_name+'%'

Select @TimeDiff = DATEDIFF(hh,GETUTCDATE(),GETDATE())

SELECT D1.event_time AS UTC_Time, DATEADD(hh,@TimeDiff,D1.event_time) AS event_time, A.action_name, C1.class_type_desc,  O.database_name, O.object_name, 
O.schema_name, C2.client_address, D2.database_principal_name, 
S2.server_principal_name, S1.statement
FROM aud.AuditLog_DDLActions D1 
join aud.auditedAction A on D1.audited_action_id = A.audited_action_id
join aud.AuditedClassType C1 on D1.audited_class_type_id = C1.audited_class_type_id
join aud.AuditedObject O on D1.audited_object_id = O.audited_object_id
join aud.ClientAddress C2 on D1.client_address_id = C2.client_address_id
join aud.DatabasePrincipalName D2 on D1.database_principal_name_id = D2.database_principal_name_id
join aud.ServerPrincipalName S2 on D1.server_principal_name_id = S2.server_principal_name_id
join aud.Statement S1 on D1.statement_id = S1.statement_id
Where O.server_instance_name = @Instance_name AND S2.server_principal_name LIKE @pString
    AND DATEADD(hh,@TimeDiff,D1.event_time) >= @StartTime AND DATEADD(hh,@TimeDiff,D1.event_time) <= @EndTime
Order by D1.event_time
GO
